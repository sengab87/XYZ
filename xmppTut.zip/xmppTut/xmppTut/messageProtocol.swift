//
//  messageProtocol.swift
//  xmppTut
//
//  Created by Ahmed Sengab on 8/2/18.
//  Copyright © 2018 Ahmed Sengab. All rights reserved.
//

import Foundation
protocol messageProtocol {
    func connect()
}
