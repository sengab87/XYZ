//
//  singelton.swift
//  xmppTut
//
//  Created by Ahmed Sengab on 7/30/18.
//  Copyright © 2018 Ahmed Sengab. All rights reserved.
//

import Foundation
import UserNotifications
class XMPPTest:NSObject , XMPPStreamDelegate, UNUserNotificationCenterDelegate{
    
    static let shared = XMPPTest()
    let password = "sengab12"
    let userJIDString = "ahmed"
    let jid = XMPPJID()
    let stream = XMPPStream()
    let port = 5222
    let host = "www.estore87.com"
    override init()
    {
        super.init()
        self.stream?.hostName = host
        self.stream?.hostPort = UInt16(port)
        self.stream?.startTLSPolicy = XMPPStreamStartTLSPolicy.allowed
        self.stream?.myJID = XMPPJID(string: userJIDString + "@" + host)
        //print(self.stream?.hostPort)
        //print(self.stream?.hostName)
        //print(self.stream?.myJID)
         self.stream?.addDelegate(self, delegateQueue: DispatchQueue.main)
         
    }
    
    
    
    
    func connect()
    {
        if !(self.stream?.isDisconnected())!
        {
            return
        }
        try! self.stream?.connect(withTimeout: XMPPStreamTimeoutNone)
        
    }
    func xmppStreamDidConnect(_ sender: XMPPStream!) {
        print("connected")
        try! stream?.authenticate(withPassword: self.password)
        
    }
    func xmppStreamDidAuthenticate(_ sender: XMPPStream!) {
        print("Authenticated")
        self.stream?.send(XMPPPresence())
        
        //self.sendMessage()
    }
    func xmppStream(_ sender: XMPPStream!, didFailToSend presence: XMPPPresence!, error: Error!) {
        // print(error)
    }
    func xmppStream(_ sender: XMPPStream!, didSend presence: XMPPPresence!) {
        print("presence sent")
    }
    func xmppStream(_ sender: XMPPStream!, didSend message: XMPPMessage!) {
        print("sent message")
    }
    func xmppStream(_ sender: XMPPStream!, didFailToSend message: XMPPMessage!, error: Error!) {
        //print(error)
    }
    func xmppStreamDidDisconnect(_ sender: XMPPStream!, withError error: Error!) {
        print("Disconneted")
        //print(error)
    }
    func sendMessage(user: String, messagetype:String, message:String)
    {
        let tagret = XMPPJID(string: user + "@www.estore87.com")
        let xmppmessage = XMPPMessage(type: messagetype, to: tagret)
        xmppmessage?.addBody(message)
        self.stream?.send(xmppmessage)
    }
    func xmppStream(_ sender: XMPPStream!, didReceive message: XMPPMessage!) {
        
      if (message.hasChatState())
      {
        if (message.hasActiveChatState())
        {
            if (message.isMessageWithBody())
            {
              
               if let messagebody = message.body()
               {
                NotificationCenter.default.post(name: Notification.Name(rawValue: "messagepass"), object: nil, userInfo: ["message":messagebody])
                
                print(messagebody)
                let content = UNMutableNotificationContent()
                
                //adding title, subtitle, body and badge
                content.title = "Hey this is Simplified iOS"
                content.subtitle = "iOS Development is fun"
                content.body = "We are learning about iOS Local Notification"
                content.badge = 1
                let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)
                
                //getting the notification request
                let request = UNNotificationRequest(identifier: "SimplifiedIOSNotification", content: content, trigger: trigger)
                
                UNUserNotificationCenter.current().delegate = self
                
                //adding the notification to notification center
                UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
                }
                if let messagesenderbeforeParsing = message.fromStr()
                {
                    let messagesender = messagesenderbeforeParsing.split(separator: "@")
                    print(messagesender[0])
                }
            }
            
            print("online")
        }
        if (message.hasPausedChatState())
        {
            print("online")
        }
        if (message.hasComposingChatState())
        {
            print("typing")
        }
        
      }
      
    
       
    }

   
    
}
