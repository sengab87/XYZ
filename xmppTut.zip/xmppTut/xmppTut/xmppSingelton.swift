//
//  xmppSingelton.swift
//  xmppTut
//
//  Created by Ahmed Sengab on 7/23/18.
//  Copyright © 2018 Ahmed Sengab. All rights reserved.
//

/*import Foundation
enum XMPPError : Error {
    case wrongUserJID

}

class XMPPController: NSObject , XMPPStreamDelegate {
    var xmppStream: XMPPStream
    let hostName: String
    let userJID: XMPPJID
    let hostPort: UInt16
    let password: String
   
    
    init(hostName: String, userJIDString: String, hostPort: UInt16 = 5222, password: String) throws {
        guard let userJID = XMPPJID(string: userJIDString) else {
            throw XMPPError.wrongUserJID
        }
        
        self.hostName = hostName
        self.userJID = userJID
        self.hostPort = hostPort
        self.password = password
        
        self.xmppStream = XMPPStream()
        self.xmppStream.hostName = hostName
        self.xmppStream.hostPort = hostPort
        self.xmppStream.startTLSPolicy = XMPPStreamStartTLSPolicy.allowed
        self.xmppStream.myJID = userJID
        // Stream Configuration
        
    super.init()
        self.xmppStream.addDelegate(self, delegateQueue: DispatchQueue.main)
    }
   
    
    
    //static let shared = XMPPController(hostName:)
    



    func connect() {
        if !self.xmppStream.isDisconnected() {
            return
        }
        
        try! self.xmppStream.connect(withTimeout: XMPPStreamTimeoutNone)
    }
    func xmppStreamDidConnect(_ stream: XMPPStream!) {
        print("Stream: Connected")
        try! stream.authenticate(withPassword: self.password)
    }
    
    func xmppStreamDidAuthenticate(_ sender: XMPPStream!) {
        self.xmppStream.send(XMPPPresence())
        print("Stream: Authenticated")
    }
    func xmppStream(_ sender: XMPPStream!, didFailToSend presence: XMPPPresence!, error: Error!) {
       // print(error)
    }
    func xmppStream(_ sender: XMPPStream!, didSend presence: XMPPPresence!) {
        print("sent")
    }
    /*func deleg()
    {
        self.xmppStream.addDelegate(self, delegateQueue: DispatchQueue.main)
    }*/
  
}*/
