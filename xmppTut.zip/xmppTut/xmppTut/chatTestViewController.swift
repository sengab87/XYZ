//
//  chatTestViewController.swift
//  xmppTut
//
//  Created by Ahmed Sengab on 7/31/18.
//  Copyright © 2018 Ahmed Sengab. All rights reserved.
//

import UIKit

class chatTestViewController: intialViewController ,XMPPStreamDelegate {
    
  
    
    @IBOutlet weak var recievedMessage: UILabel!
    @IBOutlet weak var textField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(messagetoberec), name: Notification.Name(rawValue: "messagepass"), object: nil)

        //print(XMPPTest.shared.stream)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func message(_ sender: Any) {
        XMPPTest.shared.sendMessage(user: "dina", messagetype: "chat", message: textField.text!)
    }
    @objc func messagetoberec(notification: Notification)
    {
        if let dateVC = notification.userInfo
        {
            if let mess = dateVC["message"] as? String
            {
                self.recievedMessage.text = mess
                
            }
        }
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    /*func sendMessage()
    {
       
        
        
      
        let user = XMPPJID(string: "dina@www.estore87.com")
     
        let message = XMPPMessage(type: "chat", to: user)
        message?.addBody("hello it is me")
        
        if (XMPPTest.shared.stream?.isAuthenticated())!
        {
            print("here")
            XMPPTest.shared.stream?.send(message)
        }
    }*/
    func messagereceived(inputmessage:String)
    {
        self.recievedMessage.text = inputmessage
    }
}

