//
//  ViewController.swift
//  xmppTut
//
//  Created by Ahmed Sengab on 7/23/18.
//  Copyright © 2018 Ahmed Sengab. All rights reserved.
//

import UIKit
class ViewController: UIViewController, XMPPStreamDelegate {

    var xmpp = XMPPStream()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        /*XMPPController.init(hostName: <#T##String#>, userJIDString: <#T##String#>, password: <#T##String#>)
        xmpp.user
        // Do any additional setup after loading the view, typically from a nib.
    }
         
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
        // Dispose of any resources that can be recreated.
    }
    /*func connect()
    {
        do{
            try self.xmppStream = XMPPController.init(hostName: "35.153.72.234", userJIDString: "dina@35.153.72.234", password: "sengab")
            self.xmppStream.xmppStream.addDelegate(self, delegateQueue: DispatchQueue.main)

            
        }
        catch
        {
            print("error.")
        }
        self.xmppStream.connect()
    }
    func sendMessage()
    {
        print("sending")
        let user = XMPPJID(string: "ahmed@35.153.72.234")
        let message = XMPPMessage(type: "chat", to: user)
        message?.addBody("hello it is me")
        self.xmppStream.xmppStream.send(message)
    }*/
    func xmppStream(_ sender: XMPPStream!, didSend message: XMPPMessage!) {
        print("sent message")
    }
    func xmppStream(_ sender: XMPPStream!, didFailToSend message: XMPPMessage!, error: Error!) {
       
    }
    func xmppStream(_ sender: XMPPStream!, didReceive presence: XMPPPresence!) {
        print("presence recieved")
       // sendMessage()
    }
    func xmppStream(_ sender: XMPPStream!, didReceive message: XMPPMessage!) {
        if (message.type() == "chat")
        {
            print(message.body())
        }
    }*/
    }
}

