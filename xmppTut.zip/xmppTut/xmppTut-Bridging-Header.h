//
//  xmppTut-Bridging-Header.h
//  xmppTut
//
//  Created by Ahmed Sengab on 7/23/18.
//  Copyright © 2018 Ahmed Sengab. All rights reserved.
//

#ifndef xmppTut_Bridging_Header_h
#define xmppTut_Bridging_Header_h
#import "XMPPFramework.h"

#endif /* xmppTut_Bridging_Header_h */
