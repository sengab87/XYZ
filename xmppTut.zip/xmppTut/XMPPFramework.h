#import <Foundation/Foundation.h>


#import "XMPP.h"
#import "DDLog.h"
#import "DDTTYLogger.h"

FOUNDATION_EXPORT double XMPPFrameworkVersionNumber;
FOUNDATION_EXPORT const unsigned char XMPPFrameworkVersionString[];
