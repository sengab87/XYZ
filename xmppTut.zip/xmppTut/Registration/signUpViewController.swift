//
//  signUpViewController.swift
//  xmppTut
//
//  Created by Ahmed Sengab on 7/24/18.
//  Copyright © 2018 Ahmed Sengab. All rights reserved.
//

import UIKit

class signUpViewController: phoneNumberViewController {

    @IBOutlet weak var signUpButton: UIButton!
    @IBOutlet weak var countryView: UIView!
    @IBOutlet weak var disclosureLabel: UILabel!
    @IBOutlet weak var countryName: UILabel!
    @IBOutlet weak var numberTextField: UITextField!
    @IBOutlet weak var codeTextField: UITextField!
    override func viewDidLoad() {
        
        super.viewDidLoad()
        intializeView()
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        determineCountryCode()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func intializeView()
    {
        //// here we state main label and disclosure button
        self.mainLabel.text = "Enter Phone Number"
        mainLabelView()
        let arrow = UITableViewCell()
        arrow.frame = disclosureLabel.bounds
        arrow.accessoryType = .disclosureIndicator
        arrow.isUserInteractionEnabled = false
        disclosureLabel.addSubview(arrow)
        signUpButton.layer.cornerRadius = 5
        signUpButton.clipsToBounds = true
        
    }
    
    func determineCountryCode(){
        /// This Function Determine the Country Code
        let countryCode = UserDefaults.standard.object(forKey: "countryCode")
        let country = UserDefaults.standard.object(forKey: "countryName")
        if (countryCode == nil && country == nil)
        {
            
            countryName.text = "United States"
            codeTextField.text = "1"
        }
        else
        {
            countryName.text = countryName as? String
            codeTextField.text = countryCode as? String
        }
    }
    
    func determineCountryBasedOnCode()
    {
        //// Here we determine Country by code
        let countInCodeField = codeTextField.text?.count
        if (countInCodeField != nil)
        {
            if (countInCodeField! < 4)
            {
                outerLoop: for index in 0...countryNames.count-1
                {
                    if(codeTextField.text! == "1")
                    {
                        countryName.text? = "United States"
                        break outerLoop
                    }
                    innerLoop: if ("+"+codeTextField.text!) == codes[index]
                    {
                        countryName.text? = countryNames[index]
                        break outerLoop
                    }
                    else
                    {
                        countryName.text? = "Invalid Country Code"
                    }
                }
            }
            else
            {
                countryName.text? = "Invalid Country Code"
            }
        }
    }
    @IBAction func codeTextFieldDidChange(_ sender: UITextField) {
        //// Here we check if code is changed and based on it we get country
        if (sender.text?.isEmpty)!
        {
            countryName.text = "Select from list"
        }
        else
        {
            determineCountryBasedOnCode()
        }
    }
    

}
