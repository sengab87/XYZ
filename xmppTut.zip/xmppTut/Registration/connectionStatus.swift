//
//  connectionStatus.swift
//  xmppTut
//
//  Created by Ahmed Sengab on 7/24/18.
//  Copyright © 2018 Ahmed Sengab. All rights reserved.
//

import UIKit

class connectionStatus: UIViewController {

    var reachability = Reachability()
    let red:CGFloat = 67.4512825906277/255.0
    let green:CGFloat = 215.241137444973/255.0
    let blue:CGFloat = 108.674077391624/255.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.setValue(true, forKey: "hidesShadow")
        NotificationCenter.default.addObserver(self, selector: #selector(reachabilityChanged(note:)), name: .reachabilityChanged, object: reachability)
        do
        {
            try reachability?.startNotifier()
        }catch
        {
            
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @objc func reachabilityChanged(note: Notification) {
        let reachability = note.object as! Reachability
        if (reachability.connection != .none) {
            
        }
        else
        {
            self.navigationController?.title = "Check Internet Connection"
        }
    }


}
